# Importar as bibliotecas necessárias
import numpy as np
import argparse
import cv2 as cv

# Define constantes para os nomes dos arquivos de rótulos, configuração e pesos do modelo YOLO.
LABELS_FILE = r"C:\Users\lmatr\Desktop\yolo\darknet-master\cfg\coco.names"
CONFIG_FILE = r"C:\Users\lmatr\Desktop\yolo\darknet-master\cfg\yolov4.cfg"
WEIGHTS_FILE = r"C:\Users\lmatr\Desktop\yolo\darknet-master\cfg\yolov4.weights"

# Define um limiar de confiança para detecção de objetos.
CONFIDENCE_THRESHOLD = 0.3

# Lê os rótulos do arquivo e os armazena em uma lista.
LABELS = open(LABELS_FILE).read().strip().split("\n")

# Define uma semente para geração de números aleatórios para cores.
np.random.seed(4)
# Gera cores aleatórias para cada rótulo.
COLORS = np.random.randint(0, 255, size = (len(LABELS), 3), dtype = "uint8")

# Carrega o modelo YOLO a partir dos arquivos de configuração e pesos.
net = cv.dnn.readNetFromDarknet(CONFIG_FILE, WEIGHTS_FILE)

# A função a seguir percorre os objetos detectados encontrados na imagem, 
#verifica se a confiança está acima do limite mínimo e, em caso afirmativo, 
#adiciona a caixa à matriz de caixas junto com as coordenadas em que a detecção foi descoberta.
# Em seguida, ele verifica se há mais de uma detecção e, em caso afirmativo, 
#desenha a caixa junto com o rótulo do objeto e a confiança na imagem.
# Finalmente, a imagem modificada é mostrada na tela.
def drawBoxes (image, layerOutputs, H, W):
  boxes = []
  confidences = []
  classIDs = []

  for output in layerOutputs:
    for detection in output:
      scores = detection[5:]
      classID = np.argmax(scores)
      confidence = scores[classID]

      if confidence > CONFIDENCE_THRESHOLD:
        box = detection[0:4] * np.array([W, H, W, H])
        (centerX, centerY, width, height) = box.astype("int")

        x = int(centerX - (width / 2))
        y = int(centerY - (height / 2))

        boxes.append([x, y, int(width), int(height)])
        confidences.append(float(confidence))
        classIDs.append(classID)

  idxs = cv.dnn.NMSBoxes(boxes, confidences, CONFIDENCE_THRESHOLD, CONFIDENCE_THRESHOLD)

  if len(idxs) > 0:
    for i in idxs.flatten():
      (x, y) = (boxes[i][0], boxes[i][1])
      (w, h) = (boxes[i][2], boxes[i][3])

      color = [int(c) for c in COLORS[classIDs[i]]]

      cv.rectangle(image, (x, y), (x + w, y + h), color, 2)
      text = "{}: {:.4f}".format(LABELS[classIDs[i]], confidences[i])
      cv.putText(image, text, (x, y - 5), cv.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)

  cv.imshow("Imagem com Objetos Detectados", image)

# A próxima função lê um arquivo de imagem do caminho fornecido, 
#cria um blob da imagem e define a entrada da rede.
# Em seguida, obtemos as saídas da camada e passamos as variáveis 
#necessárias para a função que foi definida acima.
def detectObjects (imagePath):
  image = cv.imread(imagePath)
  (H, W) = image.shape[:2]

  ln = net.getLayerNames()
  ln = [ln[i - 1] for i in net.getUnconnectedOutLayers()]

  blob = cv.dnn.blobFromImage(image, 1 / 255.0, (416, 416), swapRB = True, crop = False)
  net.setInput(blob)
  layerOutputs = net.forward(ln)
  drawBoxes(image, layerOutputs, H, W)

# Execução do programa principal via linha de comando com argumentos
# Usamos argparse para ler o caminho do arquivo na linha de comando, chamar a 
#função acima e esperar que o usuário pressione qualquer tecla.
# Uma vez feito isso, limpamos destruindo a janela.
if __name__ == "__main__":
  ap = argparse.ArgumentParser()
  ap.add_argument("-i", "--image", required = True, help = r"C:\Users\lmatr\Desktop\yolo\images.jpg")

  args = vars(ap.parse_args())
  detectObjects(args["image"])

  cv.waitKey(0)
  cv.destroyAllWindows()