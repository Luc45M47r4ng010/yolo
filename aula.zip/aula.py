from ultralytics import YOLO

model = YOLO('YOLO11n.pt')

resultado = model('img.jpeg')

resultado[0].show()
